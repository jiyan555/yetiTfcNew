<?php
session_start();
require("webconfig.php"); 

$legend = "Failure";
$headline = "Failure";

require("masterTop.php"); 
?>

<?php
require("masterBottom.php"); 
?>
