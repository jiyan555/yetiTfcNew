<?php
session_start();
require("webconfig.php"); 

$legend = "Profiles";
$headline = "Choose a Profile";


// WebService Call to DecisionLogic API

// Turn off WSDL caching (during testing)
$ini = ini_set("soap.wsdl_cache_enabled","0");

// SoapClient
$client = new SoapClient($serviceWSDL);

// Request
$requestParms = array('serviceKey' => $serviceKey);

// Call "GetProfiles" to build DropDownList
$options = "";
try 
{
	$result = $client->GetProfiles($requestParms)->GetProfilesResult;
	if(is_array($result->ProfileSummary)) 
	{ 
		$result = $result->ProfileSummary; 
	} 
	else 
	{ 
		$result = array($result->ProfileSummary); 
	} 
	foreach($result as $item)
	{
		$options .= "<option value='" . $item->ProfileGuid . "'>" . $item->Name . "</option>";
	}

}
catch (Exception $ex)
{
	var_dump($ex);
}

require("masterTop.php"); 

?>

<form action='bankinfo.php' method='post'>
		<table cellpadding='5' cellspacing='5' border='0' style='width: 100%;'>
			<tr>
				<td align='right' valign='middle' style='width: 30%;'>
					Profiles
				</td>
				<td align='left' valign='middle' style='width: 70%;'>
					<select name='ddlProfiles' id='ddlProfiles'>
						<option value=''>Please choose...</option> 
						<?php echo $options ?> 
					</select>
				</td>
			</tr>
			<tr>
				<td>
				</td>
				<td align='left' valign='top'>
					<input type='submit' name='btnSave' value='Submit' id='btnSave' class='button' />
				</td>
			</tr>
		</table>
</form>

<?php
require("masterBottom.php"); 
?>
