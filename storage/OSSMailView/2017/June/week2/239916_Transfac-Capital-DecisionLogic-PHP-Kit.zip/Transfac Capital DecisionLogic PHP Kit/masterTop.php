<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	session_start();
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DecisionLogic | Integration | PHP Source Code Kit |<?php echo $legend ?></title>
<link id="link1" rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link id="link2" rel="icon" href="favicon.ico" type="image/ico" />
<link rel="stylesheet" href="StyleSheet.css" type="text/css" />
<script src="scripts/jquery-1.6.2.min.js" type="text/javascript"></script>
<script src="scripts/postMessage.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">
	$.receiveMessage(
		function (e) {
			processMessage(e.data);
		},
		'https://widget.decisionlogic.com'
	);

	function IAVResultJSON(jsonString) {
		var rawJSONString = unescape(jsonString);
		var iavResultObj = $.parseJSON(rawJSONString);
		var displayString = "";
		for (var key in iavResultObj) {
			if (iavResultObj.hasOwnProperty(key)) {
				displayString += key + " : " + iavResultObj[key] + "\n\r";
			}
		}
		alert(displayString);
	}
</script>
<script language="javascript">
	$('.input').keypress(function(e) {
        if(e.which == 13) {
            jQuery(this).blur();
            jQuery('#submit').focus().click();
        }
    });
</script>
<script type="text/javascript">
	function setFocus() {
	<?php if ($focusElementId != "")
	{
	?>
	if (document.getElementById('<?php echo $focusElementId ?>') != null) {
				document.getElementById('<?php echo $focusElementId ?>').focus();
			}
	<?php
		}
	?>
	}
 </script>
</head>
<body onload="setFocus()">
<div class="page">
<div class="header">
  <table border="0" cellpadding="2" cellspacing="2" class="width100pct">
    <tr>
      <td align="left" valign="middle"><h1>DecisionLogic Integration PHP Source Code Kit</h1></td>
    </tr>
  </table>
</div>
<div id="menu">
  <div id="navcontainer">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li> <a href="profiles.php">Create Request Code</a> </li>
      <li> <a href="reportsummary.php">Reports Summary</a> </li>
      <li> <a href="sendrequestbysms.php">Send Request by SMS</a> </li>
    </ul>
  </div>
</div>
<div class="main">
<fieldset>
<legend><?php echo $legend ?></legend>
<h3>
  <p><?php echo $headline ?></p>
</h3>
