<?php
session_start();
require("webconfig.php"); 

$legend = "Send SMS";
$headline = "Send SMS";

$requestCode = "";
if (isset($_POST['tbRequestCode']))
{
	$requestCode = $_POST['tbRequestCode'];
}

$mobilePhoneNumber = "";
if (isset($_POST['tbMobilePhoneNumber']))
{
	$mobilePhoneNumber = $_POST['tbMobilePhoneNumber'];
}

	// WebService Call to DecisionLogic API
	
	// Turn off WSDL caching (during testing)
	$ini = ini_set("soap.wsdl_cache_enabled","0");
	
	// SoapClient
	$client = new SoapClient($serviceWSDL);
	
	// string serviceKey, string siteUserGuid, string profileGuid, string customerId, string firstName, string lastName, string accountNumber, string routingNumber, int contentServiceId
	// Request
	$requestParms = array(
			'serviceKey' => $serviceKey,
			'toPhone' => $mobilePhoneNumber,
			'requestCode' => $requestCode
		);
	
	// Call "CreateRequest" to get requestCode for the IFRAME src
	try 
	{
		$errorMessage = $client->SendRequestBySMS ($requestParms)->SendRequestBySMSResult;
	}
	catch (Exception $ex)
	{
		var_dump($ex);
	}


require("masterTop.php"); 
?>

<?php echo $errorMessage ?>

<?php
require("masterBottom.php"); 
?>