<?php
session_start();
require("webconfig.php"); 

$legend = "Success";
$headline = "Success";

require("masterTop.php"); 
?>

<?php
require("masterBottom.php"); 
?>
