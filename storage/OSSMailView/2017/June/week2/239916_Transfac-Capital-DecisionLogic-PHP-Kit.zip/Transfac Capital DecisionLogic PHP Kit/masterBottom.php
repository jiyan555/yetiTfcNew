    </fieldset>
  </div>
  <div class='debugger'> <?php echo $debugger ?> </div>
</div>
<div class="footer">&copy; Clarilogic, Inc. (d.b.a DecisionLogic) 2012</div>
</body>
</html>