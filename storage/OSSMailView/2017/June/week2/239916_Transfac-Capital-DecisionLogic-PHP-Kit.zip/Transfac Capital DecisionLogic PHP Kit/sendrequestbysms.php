<?php
session_start();
require("webconfig.php"); 

$legend = "Send Request by SMS";
$headline = "DecisionLogic Integration - Sample Site (for PHP Developers)";

require("masterTop.php"); 
?>

<h1>Send Request by SMS</h1>
<p> This page illustrates how to send a Request Code invitation to a borrower's mobile phone using our SMS Text messaging API. </p>
<center>
  <form action='sendsms.php' method='post'>
    <table border='0' cellpadding=='2' cellspacing='2'>
      <tr>
        <td align="right"> Request Code </td>
        <td><input type='text' name='tbRequestCode' value='' id='tbRequestCode' /></td>
      </tr>
      <tr>
        <td align="right"> Mobile Phone Number </td>
        <td><input type='text' name='tbMobilePhoneNumber' value='' id='tbMobilePhoneNumber' /></td>
      </tr>
      <tr>
        <td></td>
        <td><input type='submit' name='btnSend' value='Send' id='btnSend' class='button' /></td>
      </tr>
    </table>
  </form>
</center>
<?php
require("masterBottom.php"); 
?>