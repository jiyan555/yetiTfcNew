<?php
session_start();
require("webconfig.php"); 

$legend = "Instant Account Verification";
$headline = "Instant Account Verification";

$requestCode = "";
if (isset($_POST['tbRequestCode']))
{
	$requestCode = $_POST['tbRequestCode'];
}

if ($requestCode == "")
{
	$profileGuid = $_POST['hfProfileGuid'];
	$firstName = $_POST['tbFirstName'];
	$lastName = $_POST['tbLastName'];
	$routingNumber = $_POST['tbRoutingNumber'];
	$accountNumber = $_POST['tbAccountNumber'];
	
	$customerId = uuid();
	$contentServiceId = 0;
	
	// WebService Call to DecisionLogic API
	
	// Turn off WSDL caching (during testing)
	$ini = ini_set("soap.wsdl_cache_enabled","0");
	
	// SoapClient
	$client = new SoapClient($serviceWSDL);
	
	// string serviceKey, string siteUserGuid, string profileGuid, string customerId, string firstName, string lastName, string accountNumber, string routingNumber, int contentServiceId
	// Request
	$requestParms = array(
			'serviceKey' => $serviceKey,
			'siteUserGuid' => $siteUserGuid,
			'profileGuid' => $profileGuid,
			'customerId' => $customerId,
			'firstName' => $firstName,
			'lastName' => $lastName,
			'accountNumber' => $accountNumber,
			'routingNumber' => $routingNumber,
			'contentServiceId' => $contentServiceId
		);
	
	// Call "CreateRequest" to get requestCode for the IFRAME src
	try 
	{
		$requestCode = $client->CreateRequest($requestParms)->CreateRequestResult;
	}
	catch (Exception $ex)
	{
		var_dump($ex);
	}
}

require("masterTop.php"); 
?>

<iframe id='iframe1' src='https://widget.decisionlogic.com/Service.aspx?requestCode=<?php echo $requestCode ?>' frameborder='0' width='870' height='450' />

<?php
require("masterBottom.php"); 
?>
