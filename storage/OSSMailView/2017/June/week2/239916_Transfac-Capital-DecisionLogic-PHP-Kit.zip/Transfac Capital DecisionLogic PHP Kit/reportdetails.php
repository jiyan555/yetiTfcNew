<?php
session_start();
require("webconfig.php"); 

$legend = "Report Details";
$headline = "";

require("masterTop.php"); 
?>

<?php

$requestCode = isset($_GET["requestcode"]) ? $_GET["requestcode"] : "";
$custId = isset($_GET["custid"]) ? $_GET["custid"] : "";

$reportDetail = "";
$isValid = false;

if ($requestCode != "")
{
	// Call DecisionLogic API : GetReportDetailFromRequestCode3
	
	// Turn off WSDL caching (during testing)
	$ini = ini_set("soap.wsdl_cache_enabled","0");
	
	// SoapClient
	$client = new SoapClient($serviceWSDL);
	
	// string serviceKey, string siteUserGuid, string requestCode
	// Request
	$requestParms = array(
			'serviceKey' => $serviceKey,
			'siteUserGuid' => $siteUserGuid,
			'requestCode' => $requestCode
		);
	
	// Call "GetReportDetailFromRequestCode3" 
	try 
	{
		$reportDetail = $client->GetReportDetailFromRequestCode3($requestParms)->GetReportDetailFromRequestCode3Result;
		$isValid = true;
	}
	catch (Exception $ex)
	{
		var_dump($ex);
	}
	
	
}
else
{
	if ($custId != "")
	{
		// Call DecisionLogic API : GetReportDetailFromCustomerIdentifier3
		
		// Turn off WSDL caching (during testing)
		$ini = ini_set("soap.wsdl_cache_enabled","0");
		
		// SoapClient
		$client = new SoapClient($serviceWSDL);
		
		// string serviceKey, string siteUserGuid, string customerIdentifier
		// Request
		$requestParms = array(
				'serviceKey' => $serviceKey,
				'siteUserGuid' => $siteUserGuid,
				'customerIdentifier' => $custId
			);
		
		// Call "GetReportDetailFromCustomerIdentifier3" 
		try 
		{
			$reportDetail = $client->GetReportDetailFromCustomerIdentifier3($requestParms)->GetReportDetailFromCustomerIdentifier3Result;
			$isValid = true;
		}
		catch (Exception $ex)
		{
			var_dump($ex);
		}
		
		
	}
}


if ($isValid)
{
?>

<table border="0" cellpadding="4" cellspacing="4" class="width100pct">
	<tr>
		<td align="left">
			<table border="0" cellpadding="3" cellspacing="3" width="100%">
				<tr>
					<td align="left" valign="top" colspan="2">
						<h2>
							Request (Information Entered)</h2>
					</td>
					<td colspan="2" align="right">
						<table border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td align="right" class="prompt">
									Cust Id
								</td>
								<td style="padding-left: 8px;">
									<span><?php echo $reportDetail->CustomerIdentifier ?></span>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt" style="width: 18%;">
						Request Code
					</td>
					<td align="left" style="width: 32%;">
						<span><?php echo $reportDetail->RequestCode ?></span>
					</td>
					<td align="right" class="prompt" style="width: 18%;">
						Institution Name
					</td>
					<td align="left" style="width: 32%;">
						<span><?php echo $reportDetail->InstitutionName ?></span>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt">
						Name
					</td>
					<td align="left">
						<span><?php echo $reportDetail->NameEntered ?></span>
					</td>
					<td align="right" class="prompt">
						Routing Number
					</td>
					<td align="left">
						<span><?php echo $reportDetail->RoutingNumberEntered ?></span>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt">
						Email Address
					</td>
					<td align="left">
						<span><?php echo $reportDetail->EmailAddress ?></span>
					</td>
					<td align="right" class="prompt">
						Account Number
					</td>
					<td align="left">
						<span><?php echo $reportDetail->AccountNumberEntered ?></span>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td align="left">
			<table border="0" cellpadding="3" cellspacing="3" width="100%">
				<tr>
					<td align="left" valign="top" colspan="4">
						<h2>
							Response (Information Returned by Bank)</h2>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt" style="width: 18%;">
						Login
					</td>
					<td align="left" style="width: 32%;">
						<span>
						<?php
						if ($reportDetail->IsLoginValid == 1)
						{
							echo "Successful";
						}
						else
						{
							if ($reportDetail->LastRefreshErrorMessage != "")
							{
								echo $reportDetail->LastRefreshErrorMessage;
							}
							else
							{
								echo "Not Successful";
							}
						}
						?>
                        </span>
					</td>
					<td align="right" class="prompt" style="width: 18%;">
						Account Number
					</td>
					<td align="left" style="width: 32%;">
						<span><?php echo $reportDetail->AccountNumberFound ?></span>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt">
						Name
					</td>
					<td align="left">
						<span><?php echo $reportDetail->NameFound ?></span>
					</td>
					<td align="right" class="prompt">
						Account Name
					</td>
					<td align="left">
						<span><?php echo $reportDetail->AccountName ?></span>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt">
						Status
					</td>
					<td align="left">
						<table border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td>
									<div style='width: 6px; height: 16px; background-color: <?php echo $reportDetail->StatusCodeColor ?>; margin-right: 4px;' />
								</td>
								<td>
									<span><?php echo $reportDetail->StatusText ?></span>
								</td>
							</tr>
						</table>
					</td>
					<td align="right" class="prompt">
						Account Type
					</td>
					<td align="left">
						<span><?php echo $reportDetail->AccountType ?></span>
					</td>
				</tr>
			</table>
		</td>
	</tr>
    <?php
	if ($reportDetail->Notes != "")
	{
		?>
            <tr>
                <td align="left">
                    <table border="0" cellpadding="3" cellspacing="3" width="100%">
                        <tr>
                            <td align="left" valign="top">
                                <h2>
                                    Notes
                                </h2>
                            </td>
                        </tr>
                        <tr>
                            <td align="left">
                                <span>
                                    <?php echo $reportDetail->Notes ?>
                                </span>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
    	<?php
	}
	?>
	<tr>
		<td align="left">
			<table border="0" cellpadding="3" cellspacing="3" width="100%">
				<tr>
					<td align="left" valign="top" colspan="4">
						<h2>
							Summary
                        </h2>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt" style="width: 18%;">
						Available Balance
					</td>
					<td align="left" style="width: 32%;">
						<span><?php echo "$" . number_format($reportDetail->AvailableBalance, 2) ?></span>
					</td>
					<td align="right" class="prompt" style="width: 18%;">
						As of Date
					</td>
					<td align="left" style="width: 32%;">
						<span>
						<?php
							$asOfDate = strtotime($reportDetail->AsOfDate);
							echo date("m/d/Y g:i a", $asOfDate); 
						?>
                        </span>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt" style="width: 18%;">
						Current Balance
					</td>
					<td align="left" style="width: 32%;">
						<span><?php echo "$" . number_format($reportDetail->CurrentBalance, 2) ?></span>
					</td>
					<td align="right" class="prompt" style="width: 18%;">
						Average Balance
					</td>
					<td align="left" style="width: 32%;">
						<span><?php echo "$" . number_format($reportDetail->AverageBalance, 2) ?></span>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt" style="width: 18%;">
						Deposits/Credits
					</td>
					<td align="left" style="width: 32%;">
						<span><?php echo "$" . number_format($reportDetail->TotalCredits, 2) ?></span>
					</td>
					<td align="right" class="prompt">
						Avg Bal Latest Month
					</td>
					<td align="left">
						<span><?php echo "$" . number_format($reportDetail->AverageBalanceRecent, 2) ?></span>
					</td>
				</tr>
				<tr>
					<td align="right" class="prompt">
						Withdrawals/Debits
					</td>
					<td align="left">
						<span><?php echo "$" . number_format($reportDetail->TotalDebits, 2) ?></span>
					</td>
					<td align="right" class="prompt" style="width: 18%;">
						Workflow
					</td>
					<td align="left" style="width: 32%;">
						<span>
						<?php 
						
						switch ($reportDetail->ProcessedStatus)
						{
							case 0:
								echo "Unknown";
								break;
							case 1:
								echo "New";
								break;
							case 2:
								echo "Pending Review";
								break;
							case 3:
								echo "Accepted";
								break;
							case 4:
								echo "Rejected";
								break;
							case 5:
								echo "Escalated";
								break;
						}
								
						?>
                        </span>
					</td>
				</tr>
                <?php
				if ($reportDetail->IsActivityAvailable)
				{
				?>
				<tr>
					<td align="left" valign="top" colspan="4" style="padding-top: 10px;">
						<div>
							<table cellspacing="2" cellpadding="2" style="width: 100%;">
								<tr>
									<th align="left" scope="col">
										Description
									</th>
									<th align="left" scope="col">
										Code
									</th>
									<th align="right" scope="col">
										Transactions
									</th>
									<th align="right" scope="col">
										Total
									</th>
									<th align="right" scope="col">
										Transactions Last Month
									</th>
									<th align="right" scope="col">
										Total Last Month
									</th>
								</tr>
                                <?php
								for($i=0; $i<7; $i++)
								{
									?>
									<tr 
                                    	<?php
										
										if ($i % 2 == 0)
										{
											echo " style='background-color: #F0F0F0;' ";
										}
										
										?>
                                    >
										<td valign="top" style="width: 19%;">
											<span><?php echo $reportDetail->TransactionAnalysisSummaries->TransactionAnalysisSummary3[$i]->TypeName ?></span>
										</td>
										<td valign="top" style="width: 5%;">
											<span><?php echo $reportDetail->TransactionAnalysisSummaries->TransactionAnalysisSummary3[$i]->TypeCode ?></span>
										</td>
										<td align="right" style="width: 18%;">
											<span><?php echo $reportDetail->TransactionAnalysisSummaries->TransactionAnalysisSummary3[$i]->TotalCount ?></span>
										</td>
										<td align="right" style="width: 18%;">
											<span><?php echo "$" . number_format($reportDetail->TransactionAnalysisSummaries->TransactionAnalysisSummary3[$i]->TotalAmount, 2) ?></span>
										</td>
										<td align="right" style="width: 20%;">
											<span><?php echo $reportDetail->TransactionAnalysisSummaries->TransactionAnalysisSummary3[$i]->RecentCount ?></span>
										</td>
										<td align="right" style="width: 20%;">
											<span><?php echo "$" . number_format($reportDetail->TransactionAnalysisSummaries->TransactionAnalysisSummary3[$i]->RecentAmount, 2) ?></span>
										</td>
									</tr>
									<?php
								}
								?>
							</table>
						</div>
					</td>
				</tr>
                <?php
				}
				?>
			</table>
		</td>
	</tr>
    <?php
	if ($reportDetail->IsActivityAvailable)
	{
	?>
	<tr>
		<td align="left">
			<table border="0" cellpadding="3" cellspacing="3" class="width100pct">
				<tr>
					<td align="left" valign="top" colspan="2">
						<h2>
							Transactions</h2>
					</td>
					<td align="right">
						<table border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td align="right" class="prompt">
									Dates
								</td>
								<td style="padding-left: 8px;">
									<span>
                                    <?php
										$activityStartDate = strtotime($reportDetail->ActivityStartDate);
										$activityEndDate = strtotime($reportDetail->ActivityEndDate);
										
										echo date("m/d/Y", $activityStartDate) . " - " . date("m/d/Y", $activityEndDate); 
									?>
                                    </span>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td align="left" valign="top" colspan="4">
						<div>
							<table cellspacing="2" cellpadding="2" id="MainContent_gvTrans" style="width: 100%;">
								<tr>
									<th align="left" scope="col">
										Date
									</th>
									<th align="left" scope="col">
										Codes
									</th>
									<th align="left" scope="col">
										Description
									</th>
									<th align="right" scope="col">
										Amount
									</th>
									<th align="right" scope="col">
										Balance
									</th>
								</tr>
                                <?php
								$transactions = $reportDetail->TransactionSummaries->TransactionSummary3;
								
								for($i=0; $i<count($transactions); $i++)
								{
									$className = "gv";
									$className .= ($i % 2 == 0) ? "_RowEven" : "_RowOdd";
									$className .= ($transactions[$i]->Amount < 0) ? "_AmountNegative" : "_AmountPositive";
									$className .= ($transactions[$i]->IsRefresh) ? "_RefreshYes" : "_RefreshNo";
									$className .= ($transactions[$i]->Status == "pending") ? "_PendingYes" : "_PendingNo";
									
									$transactionDate = date("m/d/Y", strtotime($transactions[$i]->TransactionDate) );
									$transactionCodes = $transactions[$i]->TypeCodes;
									$transactionDescription = $transactions[$i]->Description;
									if ($transactions[$i]->Status == "pending")
									{
										$transactionDescription = "(Pending) " + $transactionDescription;
									}
									$transactionAmount = "$" . number_format($transactions[$i]->Amount, 2);
									$transactionBalance = "$" . number_format($transactions[$i]->RunningBalance, 2);
									
									?>
									<tr class="<?php echo $className ?>">
										<td valign="top" style="width: 10%;">
											<span><?php echo $transactionDate ?></span>
										</td>
										<td valign="top" style="width: 10%;">
											<span><?php echo $transactionCodes ?></span>
										</td>
										<td valign="top" style="width: 60%;">
											<span><?php echo $transactionDescription ?></span>
										</td>
										<td align="right" valign="top" style="width: 10%;">
											<span><?php echo $transactionAmount ?></span>
										</td>
										<td align="right" valign="top" style="width: 10%;">
											<span><?php echo $transactionBalance ?></span>
										</td>
									</tr>
									<?php
								}
								?>
							</table>
						</div>
					</td>
				</tr>
			</table>
		</td>
	</tr>
    <?php
	}
	?>
</table>

<?php
}


require("masterBottom.php"); 
?>
