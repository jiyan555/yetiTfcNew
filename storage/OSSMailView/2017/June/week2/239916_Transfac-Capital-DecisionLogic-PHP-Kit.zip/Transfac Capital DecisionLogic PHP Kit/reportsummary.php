<?php
session_start();
require("webconfig.php"); 

$legend = "Reports Summary";
$headline = "Search Reports";

require("masterTop.php"); 
?>

<form action='reportsummaries.php' method='post'>
	<table border="0" cellpadding="2" cellspacing="2">
		<tr>
			<td align="right" class="prompt">
				Search Term
			</td>
			<td align="left" class="field">
				<input name="tbSearchTerm" type="text" id="tbSearchTerm" />
			</td>
		</tr>
		<tr>
			<td align="right" class="prompt">
				Date From
			</td>
			<td align="left" class="field">
				<input name="tbFromDate" type="text" value="01/01/2012" id="tbFromDate" />
			</td>
		</tr>
		<tr>
			<td align="right" class="prompt">
				Date To
			</td>
			<td align="left" class="field">
				<input name="tbToDate" type="text" value="12/31/2012" id="tbToDate" />
			</td>
		</tr>
		<tr>
			<td align="right" class="prompt">
				Time Zone Offset
			</td>
			<td align="left" class="field">
				<input name="tbTimeZoneOffset" type="text" value="0" id="tbTimeZoneOffset" />
			</td>
		</tr>
		<tr>
			<td align="right" class="prompt">
				Status
			</td>
			<td align="left" class="field">
				<select name="ddlStatus" id="ddlStatus">
	<option selected="selected" value="0">Any</option>
	<option value="1">Not Started</option>
	<option value="2">Started, Not Completed</option>
	<option value="3">Started, Completed</option>
	<option value="4">Started, Completed, Not Verified</option>
	<option value="5">Started, Completed, Verified</option>

</select>
			</td>
		</tr>
		<tr>
			<td align="right" class="prompt">
				Processed Status
			</td>
			<td align="left" class="field">
				<select name="ddlProcessedStatus" id="ddlProcessedStatus">
	<option selected="selected" value="0">Any</option>
	<option value="1">New</option>
	<option value="2">Pending Review</option>
	<option value="3">Accepted</option>
	<option value="4">Rejected</option>
	<option value="5">Escalated</option>

</select>
			</td>
		</tr>
		<tr>
			<td>
			</td>
			<td align="left">
				<input type="submit" name="btnSubmit" value="Submit" id="btnSubmit" class="button" />
			</td>
		</tr>
	</table>
</form>

<?php
require("masterBottom.php"); 
?>
