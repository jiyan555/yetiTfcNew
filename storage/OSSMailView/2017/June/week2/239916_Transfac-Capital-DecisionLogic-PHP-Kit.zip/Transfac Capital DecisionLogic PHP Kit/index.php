<?php
session_start();
require("webconfig.php"); 

$legend = "Home";
$headline = "DecisionLogic Integration - Sample Site (for PHP Developers)";

require("masterTop.php"); 
?>
	<p>
		This solution brings together SOAP/XML service calls to DecisionLogic's
		Integration API and simulates the steps needed to create a very simple process flow, 
        and interact with some of the API web methods.
	</p>
	<p>
		The SOAP/XML web service can be found here:<br />
		<a href='http://www.decisionlogic.com/integration.asmx' target='_blank'>http://www.decisionlogic.com/integration.asmx</a>
	</p>
	<p>
		The SOAP/XML web service WSDL can be found (and consumed) here:<br />
		<a href='http://www.decisionlogic.com/integration.asmx?wsdl' target='_blank'>http://www.decisionlogic.com/integration.asmx?wsdl</a>
	</p>
    <h1>Option 1</h1>
    <p>
    	Normally, a "full" integration involves creating a request code from certain borrower information, and then we present an iframe that uses the request code in the src url.
    </p>
	<center>
		<form action='profiles.php' method='post'>
			<input type='submit' name='btnStart' value='Create a Request Code' id='btnStart' class='button' />
		</form>
	</center>
    <h1>Option 2</h1>
    <p>
    	If you are starting with a request code that has already been created, you can enter it here:
    </p>
    <center>
    	<form action='verification.php' method='post'>
        	<table border='0' cellpadding=='2' cellspacing='2'>
            	<tr>
                	<td>
                    	<input type='text' name='tbRequestCode' value='' id='tbRequestCode' />
                    </td>	
                    <td>
                    	<input type='submit' name='btnVerify' value='Enter Request Code' id='btnStart' class='button' />
                    </td>
                </tr>
            </table>
			
		</form>
    </center>	
<?php
require("masterBottom.php"); 
?>