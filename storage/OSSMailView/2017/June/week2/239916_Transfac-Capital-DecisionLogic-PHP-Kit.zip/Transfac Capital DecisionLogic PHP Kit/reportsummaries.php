<?php
session_start();
require("webconfig.php"); 

$legend = "Reports Summary";
$headline = "Reports";

$searchTerm = $_POST['tbSearchTerm'];
$fromDate = $_POST['tbFromDate'];
$toDate = $_POST['tbToDate'];

$fromDate = date('c', strtotime($fromDate));
$toDate = date('c', strtotime($toDate));

$timeZoneOffset = $_POST['tbTimeZoneOffset'];
if ($timeZoneOffset == '')
{
	$timeZoneOffset = 0;
}
else
{
	$timeZoneOffset = intval($timeZoneOffset);
}

$status = $_POST['ddlStatus'];
if ($status == '')
{
	$status = 0;
}
else
{
	$status = intval($status);
}

$processStatus = $_POST['ddlProcessedStatus'];
if ($processStatus == '')
{
	$processStatus = 0;
}
else
{
	$processStatus = intval($processStatus);
}

// WebService Call to DecisionLogic API

// Turn off WSDL caching (during testing)
$ini = ini_set("soap.wsdl_cache_enabled","0");

// SoapClient
$client = new SoapClient($serviceWSDL);

// client.SearchReportSummary(strng serviceKey, string siteUserGuid, string searchTerm, DateTime fromDate, DateTime toDate, int timeZoneOffset, int status, int processStatus)
// RequestSearchResult
$requestParms = array(
		'serviceKey' => $serviceKey,
		'siteUserGuid' => $siteUserGuid,
		'searchTerm' => $searchTerm,
		'fromDate' => $fromDate,
		'toDate' => $toDate,
		'timeZoneOffset' => $timeZoneOffset,
		'status' => $status,
		'processStatus' => $processStatus
	);

require("masterTop.php"); 
?>

<?php

// Call "SearchReportSummary" to get RequestSearchResult
$requestSearchResult = array();
try 
{
	$requestSearchResult = $client->SearchReportSummary($requestParms)->SearchReportSummaryResult;
}
catch (Exception $ex)
{
	var_dump($ex);
}

$errorMessage = $requestSearchResult->ErrorMessage;

if ($errorMessage == "")
{
	$searchResults = $requestSearchResult->SearchResults;
	$searchResultsListCount = count($searchResults->SearchResult);

	if ($searchResultsListCount > 0)
	{
		?>
		
			<table cellspacing="0" rules="all" border="1" style="width:100%;border-collapse:collapse;">
				<tr>
					<th scope="col">Date Created</th>
					<th scope="col">Request Code</th>
					<th scope="col">Customer Identifier</th>
					<th scope="col">Bank Name</th>
					<th scope="col">Holder Name Input</th>
					<th scope="col">Routing Number Input</th>
					<th scope="col">Account Number Input</th>
				</tr>
				
		<?php
		
		// Iterate through the parameters: AccountNumberInput, ContentServiceDisplayName, CustomerIdentifier, DateCreated, HolderNameInput, RequestCode, RoutingNumberInput
	
		for($i=0; $i<$searchResultsListCount; $i++)
		{
			$item = $searchResults->SearchResult[$i];
		
			echo "<tr>";
				echo "<td>" . date("m/d/Y g:i a", strtotime($item->DateCreated)) . "</td><td><a href='reportdetails.php?requestcode=" . $item->RequestCode . "'>" . $item->RequestCode . "</a></td>";
				echo "<td><a href='reportdetails.php?custid=" . $item->CustomerIdentifier . "'>" . $item->CustomerIdentifier . "</a></td>";
				echo "<td>" . $item->ContentServiceDisplayName . "</td>";
				echo "<td>" . $item->HolderNameInput . "</td>";
				echo "<td>" . $item->RoutingNumberInput . "</td>";
				echo "<td>" . $item->AccountNumberInput . "</td>";
			echo "</tr>";
		
		}
		
		?>
			</table>
		<?php
	}
}
else
{
	echo "<h3>Error: " . $errorMessage . "</h3>";
}

require("masterBottom.php"); 
?>
