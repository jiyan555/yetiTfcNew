<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	session_start();
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DecisionLogic | Integration | PHP Source Code Kit |<?php echo $legend ?></title>
<link id="link1" rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link id="link2" rel="icon" href="favicon.ico" type="image/ico" />
<link rel="stylesheet" href="StyleSheet.css" type="text/css" />
<script type="text/javascript">
	var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
	var eventer = window[eventMethod];
	var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";

	eventer(messageEvent, function(e) {
		if (e.origin == 'https://widget.decisionlogic.com') {
			processMessage(e.data);
		}
	}, false);

	function processMessage(s) {
		var p = s.split("|");
		if (p.length == 2) {
			if (p[0] == "Redirect") {
				document.location.href = p[1];
			}
			if (p[0] == "JSON") {
				processJSON(p[1]);
			}
		}
	}

	function toArray(obj) {
		var result = [];
		for (var prop in obj) {
			var value = obj[prop];
			if (typeof value === 'object') {
				result.push(toArray(value));
			}
			else {
				result.push(value);
			}
		}
		return result;
	}

	function processJSON(jsonString) {
		var json = unescape(jsonString);
		var obj = JSON.parse(json);
		var display = toArray(obj);
		alert(display);
	}
</script>
<script language="javascript">
	$('.input').keypress(function(e) {
        if(e.which == 13) {
            jQuery(this).blur();
            jQuery('#submit').focus().click();
        }
    });
</script>
<script type="text/javascript">
	function setFocus() {
	<?php if ($focusElementId != "")
	{
	?>
	if (document.getElementById('<?php echo $focusElementId ?>') != null) {
				document.getElementById('<?php echo $focusElementId ?>').focus();
			}
	<?php
		}
	?>
	}
 </script>
</head>
<body onload="setFocus()">
<div class="page">
<div class="header">
  <table border="0" cellpadding="2" cellspacing="2" class="width100pct">
    <tr>
      <td align="left" valign="middle"><h1>DecisionLogic Integration PHP Source Code Kit</h1></td>
    </tr>
  </table>
</div>
<div id="menu">
  <div id="navcontainer">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li> <a href="profiles.php">Create Request Code</a> </li>
      <li> <a href="reportsummary.php">Reports Summary</a> </li>
      <li> <a href="sendrequestbysms.php">Send Request by SMS</a> </li>
    </ul>
  </div>
</div>
<div class="main">
<fieldset>
<legend><?php echo $legend ?></legend>
<h3>
  <p><?php echo $headline ?></p>
</h3>
