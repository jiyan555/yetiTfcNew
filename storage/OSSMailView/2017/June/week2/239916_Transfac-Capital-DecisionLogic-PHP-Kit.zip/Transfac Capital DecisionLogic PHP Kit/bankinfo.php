<?php
session_start();
require("webconfig.php"); 

$legend = "Bank Info";
$headline = "Enter Customer Banking Information";

$profileGuid = $_POST['ddlProfiles'];

$focusElementId = "tbFirstName";

require("masterTop.php"); 
?>

<form action='verification.php' method='post'>
		<input type='hidden' id='hfProfileGuid' name='hfProfileGuid' value='<?php echo $profileGuid ?>' />
		<table cellpadding='5' cellspacing='5' border='0' style='width: 100%;'>
			<tr>
				<td align='right' valign='middle' style='width: 30%;'>
					First Name
				</td>
				<td align='left' valign='middle' style='width: 70%;'>
					<input name='tbFirstName' type='text' id='tbFirstName' style='width:200px;' />
				</td>
			</tr>
			<tr>
				<td align='right' valign='middle'>
					Last Name
				</td>
				<td align='left' valign='middle'>
					<input name='tbLastName' type='text' id='tbLastName' style='width:200px;' />
				</td>
			</tr>
			<tr>
				<td align='right' valign='middle'>
					Bank Routing Number
				</td>
				<td align='left' valign='middle'>
					<input name='tbRoutingNumber' type='text' id='tbRoutingNumber' style='width:200px;' />
				</td>
			</tr>
			<tr>
				<td align='right' valign='middle'>
					Bank Account Number
				</td>
				<td align='left' valign='middle'>
					<input name='tbAccountNumber' type='text' id='tbAccountNumber' style='width:200px;' />
				</td>
			</tr>
			<tr>
				<td>
				</td>
				<td align='left' valign='top'>
					<input type='submit' name='btnSave' value='Submit' id='btnSave' class='button' />
				</td>
			</tr>
		</table>
</form>

<?php
require("masterBottom.php"); 
?>
